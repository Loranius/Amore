-- ============================================================
-- МІГРАЦІЯ: Бюджет, Капсула часу, Питання дня
-- Прогнати в Supabase SQL Editor після schema.sql
-- ============================================================

-- ---------- EXPENSES (Бюджет) ----------
create table expenses (
  id serial primary key,
  amount numeric(10,2) not null,
  category text not null,
  description text,
  date date not null,
  created_by integer references users(id),
  created_at timestamptz default now()
);

alter table expenses enable row level security;
create policy "anon all expenses" on expenses for all using (true) with check (true);


-- ---------- TIME_CAPSULES (Капсула часу) ----------
create table time_capsules (
  id serial primary key,
  title text not null,
  content text not null,
  open_date date not null,
  created_by integer references users(id),
  created_at timestamptz default now()
);

alter table time_capsules enable row level security;
create policy "anon all time_capsules" on time_capsules for all using (true) with check (true);


-- ---------- DAILY_QUESTIONS (пул питань) ----------
create table daily_questions (
  id serial primary key,
  text text not null
);

alter table daily_questions enable row level security;
create policy "anon select daily_questions" on daily_questions for select using (true);


-- ---------- DAILY_QUESTION_LOG (відповіді на день) ----------
create table daily_question_log (
  id serial primary key,
  date date not null unique,
  question_id integer references daily_questions(id) not null,
  answer_dima text,
  answer_lena text
);

alter table daily_question_log enable row level security;
create policy "anon all daily_question_log" on daily_question_log for all using (true) with check (true);


-- ============================================================
-- ПОЧАТКОВИЙ ПУЛ ПИТАНЬ (можна доповнювати в будь-який час)
-- ============================================================

insert into daily_questions (text) values
  ('Який момент цього тижня запам''ятався найбільше?'),
  ('Що найбільше хочеш зробити разом найближчим часом?'),
  ('Яка дрібниця в партнера сьогодні тебе порадувала?'),
  ('Якби можна було телепортуватись будь-куди прямо зараз — куди б полетіли?'),
  ('Що з дитинства хотілося б показати/розповісти партнеру?'),
  ('Яка пісня зараз описує твій настрій?'),
  ('Якби сьогодні був вихідний без жодних справ — що б робили?'),
  ('Що найбільше цінуєш у стосунках саме зараз?'),
  ('Яку нову страву хотілося б спробувати приготувати разом?'),
  ('Про що мрієш на найближчий рік?'),
  ('Яке твоє найкраще спільне спогад за останній місяць?'),
  ('Що могло б зробити сьогоднішній день кращим?'),
  ('Якби можна було вивчити будь-яку навичку миттєво — яку обрав(ла) би?'),
  ('Що тебе зараз найбільше турбує і чим можу допомогти?'),
  ('Яке місце хотілося б відвідати разом найближчим часом?');

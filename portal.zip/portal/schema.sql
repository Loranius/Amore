-- ============================================================
-- ПОРТАЛ: схема БД
-- ============================================================

-- ---------- USERS ----------
create table users (
  id serial primary key,
  name text not null,
  pin_hash text not null
);

-- ---------- SETTINGS ----------
create table settings (
  key text primary key,
  value text not null
);

-- ---------- EVENTS ----------
create table events (
  id serial primary key,
  title text not null,
  date date not null,
  description text,
  created_by integer references users(id),
  created_at timestamptz default now()
);

-- ---------- WISHLIST ----------
create table wishlist_items (
  id serial primary key,
  title text not null,
  description text,
  link text,
  owner integer references users(id) not null,
  reserved boolean default false,
  reserved_by integer references users(id),
  created_at timestamptz default now()
);

-- ============================================================
-- ROW LEVEL SECURITY
-- (анонімний доступ для двох-користувацького порталу,
--  захист по суті лише через PIN на клієнті)
-- ============================================================

alter table users enable row level security;
alter table settings enable row level security;
alter table events enable row level security;
alter table wishlist_items enable row level security;

create policy "anon select users" on users for select using (true);
create policy "anon select settings" on settings for select using (true);

create policy "anon all events" on events for all using (true) with check (true);
create policy "anon all wishlist" on wishlist_items for all using (true) with check (true);

-- ============================================================
-- ПОЧАТКОВІ ДАНІ
-- ============================================================

-- PIN для обох: 26122022
-- SHA-256("26122022") = 7372afc95401b39f98d7655ce858cf861af988800516925abd2db9dc448dd785

insert into users (name, pin_hash) values
  ('Діма', '7372afc95401b39f98d7655ce858cf861af988800516925abd2db9dc448dd785'),
  ('Лєна', '7372afc95401b39f98d7655ce858cf861af988800516925abd2db9dc448dd785');

-- Дата початку стосунків
insert into settings (key, value) values
  ('relationship_start_date', '2022-12-26');
